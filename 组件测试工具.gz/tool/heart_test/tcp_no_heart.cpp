#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <pthread.h>
#include <arpa/inet.h>

//@brief:心跳格式很简单，长度为5 内容为"hello" 就认为是心跳包

int m_sockfd = 0;
static void* heart_beart(void*)
{
    char buf[] = "hello";
    int len = 5;
    while (1)
    {
        int s_len = send(m_sockfd, buf, len, 0);
        if (s_len != len)
        {
            std::cout<<"the send len:"<<s_len<<std::endl;
        }
        usleep(50*10000);
    }
}

int main(int argc, char* argv[])
{
    int m_sockfd;
    int x=1215;
    printf("%x\n", htonl(x));
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(5683);
    addr.sin_addr.s_addr = inet_addr("192.168.100.70");

    m_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    socklen_t len = sizeof(addr);
    struct sockaddr_in cliaddr;
    
     
    if (connect(m_sockfd, (struct sockaddr*)&addr, len) == -1)
    {
        std::cout<<"connect error."<<std::endl;
    }
    else
    {
        std::cout<<"connect susscess."<<std::endl;
    }
    char recvbuf[100];
    char buf[100];
    int num = 0;

    pthread_t heart_id;
    //pthread_create(&heart_id, NULL, heart_beart, NULL);
  
    while (1)
    {
        memset(recvbuf, 0, 100);
        sprintf(buf, "hello:%d", num);
        num++;
        std::string msg = buf;
        int len = send(m_sockfd, msg.c_str(), msg.length(), 0);
        std::cout<<"send-len:"<<msg.length()<<" content:"<<msg.c_str()<<std::endl;
        int recvlen = recv(m_sockfd, recvbuf, 100, 0);
        std::cout<<"recv-len:"<<recvlen<<" content:"<<recvbuf<<std::endl;
      
      
         if (num > 10* 10000 && num < 10*10000+25)
         {
            usleep(500*1000);
        }
         if (num >= 10*10000+25)
         {
             num = 0;
         }
    }

}
