#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <pthread.h>
#include <arpa/inet.h>


int main(int argc, char* argv[])
{
    int m_sockfd;
    int x=1215;
    printf("%x\n", htonl(x));
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(5681);
    addr.sin_addr.s_addr = inet_addr("192.168.100.70");

    m_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    socklen_t len = sizeof(addr);
    struct sockaddr_in cliaddr;
    
     
    if (connect(m_sockfd, (struct sockaddr*)&addr, len) == -1)
    {
        std::cout<<"connect error."<<std::endl;
    }
    else
    {
        std::cout<<"connect susscess."<<std::endl;
    }
    /*TLogin login;
    login.head.len = htonl(sizeof(TLogin));
    login.head.cmd = htonl(0x00000001);
    login.head.seq = htonl(2);

    int sendnum = send(m_sockfd, (void*)&login, sizeof(login), 0);
    std::cout<<"send login len:"<<sendnum<<std::endl;


    pthread_t tid;
    pthread_create(&tid, NULL, recv_thrd, NULL);
    */
    char recvbuf[100];
    char buf[100];
    int num = 0;
  
    while (1)
    {
        /*TBatchseq batch;
        batch.head.len = htonl(sizeof(TBatchseq));
        batch.head.cmd = htonl(0x00000028);
        batch.head.seq = htonl(3);
        memcpy(batch.batch.number, "13800000001", strlen("13800000001"));
        */
        memset(recvbuf, 0, 100);
        sprintf(buf, "hello:%d", num);
        num++;
        std::string msg = buf;
        int len = send(m_sockfd, msg.c_str(), msg.length(), 0);
        std::cout<<"send-len:"<<msg.length()<<" content:"<<msg.c_str()<<std::endl;
        int recvlen = recv(m_sockfd, recvbuf, 100, 0);
        std::cout<<"recv-len:"<<recvlen<<" content:"<<recvbuf<<std::endl;
       
         if (num > 10* 10000 && num < 10*10000+25)
        {
            usleep(500*1000);
        }
         if (num >= 10*10000+25)
         {
             num = 0;
         }
    }

}
