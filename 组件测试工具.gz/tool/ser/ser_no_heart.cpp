#include <iostream>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <vector>
#include <errno.h>
#include <sys/epoll.h>
#include <string.h>
#include <queue> 

int ser_run()
{
    unsigned short port = 5680;
	struct sockaddr_in seraddr;
	seraddr.sin_family = AF_INET;
	seraddr.sin_addr.s_addr = INADDR_ANY;
	seraddr.sin_port = htons(port);
    int sockfd;
    int reflag = 1;
    
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
   

	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &reflag, sizeof(int)) == -1)
    {
        std::cout<<"reuse addr error."<<std::endl;
    }

    if (bind(sockfd, (struct sockaddr*)&seraddr, sizeof(seraddr)) == -1)
		std::cout<<"bind error."<<"   error code:"<<errno<<std::endl;
	
    if (listen(sockfd, 100) == -1)
		std::cout<<"listen error."<<std::endl;
	struct sockaddr_in cli;
	socklen_t clilen = sizeof(cli);
	int clifd = accept(sockfd, (struct sockaddr*)&cli, &clilen);
	if (clifd <= 0)
		std::cout<<"accept error and errno:"<<errno<<std::endl;
	

    char buf[1024];
    
    while (true)
	{

        memset(buf, 0, 1024);
		int len = recv(clifd, buf, 1024, 0);
		if (len <= 0)
        {
            continue;
        }
        std::cout<<"recv-info:"<<buf<<std::endl;
        std::string msg = buf;
        if (msg == "world")
        {
            std::cout<<"recv a heart pack."<<std::endl;
        }
        send(clifd, buf, len, 0);
        std::cout<<"send-info:"<<buf<<std::endl;
    }
}

int main(void)
{
	ser_run();
}
