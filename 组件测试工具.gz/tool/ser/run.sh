g++ ser_no_heart.cpp -o no_heart -lpthread
g++ ser_with_heart.cpp -o with_heart -lpthread
