#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <errno.h>

int main(int argc, char* argv[])
{
    int m_sockfd;
    int x=1215;
    printf("%x\n", htonl(x));
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(5685);
    addr.sin_addr.s_addr = inet_addr("192.168.100.70");

    m_sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    int res = bind(m_sockfd, (struct sockaddr*)&addr, sizeof(addr));
    if (res == -1)
    {
        std::cout<<"udp ser bind error."<<std::endl;
    }
   
    std::cout<<"the sockfd:"<<m_sockfd<<std::endl;
    struct sockaddr_in seraddr;
    socklen_t addr_len = sizeof(seraddr);

    memset((void*)&seraddr, 0, sizeof(seraddr));

    int  num = 0;
    char buf[100];
    char recvbuf[100];
    while (1)
    {
        memset(recvbuf, 0, 100);
        memset(buf, 0, 100);
        // sprintf(buf, "hello:%d", num);
        num++;
        int recvlen = recvfrom(m_sockfd, recvbuf, 100, 0, (struct sockaddr*)&seraddr, &addr_len);
        unsigned short s_port = seraddr.sin_port;
        std::cout<<"recv-len:"<<recvlen<<" content:"<<recvbuf<<" from port:"<<ntohs(s_port)<<std::endl;
       
        int len = sendto(m_sockfd, recvbuf, recvlen, 0, (struct sockaddr*)&seraddr, sizeof(seraddr));
        if (len == -1)
        {
            std::cout<<"errno :"<<errno<<std::endl;
        }
        std::cout<<"send-len:"<<len<<" content:"<<recvbuf<<" to port:"<< ntohs(seraddr.sin_port)<<std::endl;
    }

}
