#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <pthread.h>
#include <arpa/inet.h>


int main(int argc, char* argv[])
{
    int m_sockfd;
    int x=1215;
    printf("%x\n", htonl(x));
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(5687);
    addr.sin_addr.s_addr = inet_addr("192.168.100.70");

    m_sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    
    struct sockaddr_in seraddr;
    socklen_t addr_len = sizeof(addr);
   

    struct sockaddr_in localaddr;
    localaddr.sin_family = AF_INET;
    localaddr.sin_port = htons(6666);
    localaddr.sin_addr.s_addr = inet_addr("192.168.100.70");
    bind (m_sockfd, (struct sockaddr*)&localaddr, sizeof(localaddr));

    int  num = 0;
    char buf[100];
    char recvbuf[100];
    while (1)
    {
        memset(recvbuf, 0, 100);
        memset(buf, 0, 100);
        sprintf(buf, "hello:%d", num);
        num++;
        std::string msg = buf;
        int len = sendto(m_sockfd, msg.c_str(), msg.length(), 0, (struct sockaddr*)&addr, sizeof(addr));
        std::cout<<"send-len:"<<msg.length()<<" content:"<<msg.c_str()<<std::endl;
        int recvlen = recvfrom(m_sockfd, recvbuf, 100, 0, (struct sockaddr*)&seraddr, &addr_len);
        std::cout<<"recv-len:"<<recvlen<<" content:"<<recvbuf<<std::endl;
       
         if (num > 10* 10000 && num < 10*10000+25)
        {
            usleep(500*1000);
        }
         if (num >= 10*10000+25)
         {
             num = 0;
         }
    }

}
